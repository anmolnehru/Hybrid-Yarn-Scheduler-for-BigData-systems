#policy conservative
./gridmix-generate.sh
./100Mbps.sh  > results/100M.txt
./10Mbps.sh > results/10M.txt 
./1Mbps.sh > results/1M.txt
./1Gbps.sh > results/1G.txt
./non_gda.sh > results/non_gda.txt
